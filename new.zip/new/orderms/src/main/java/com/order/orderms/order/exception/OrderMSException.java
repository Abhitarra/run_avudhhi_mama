package com.order.orderms.order.exception;

public class OrderMSException extends Exception {

	private static final long serialVersionUID = 1L;

	public OrderMSException(String message) {
		super(message);
	}

}
