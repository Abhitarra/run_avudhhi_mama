package com.use.userms.user.exception;

public class UserMsException extends Exception {

	private static final long serialVersionUID = 1L;

	public UserMsException(String message) {
		super(message);
	}

}
